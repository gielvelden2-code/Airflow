package com.airflow.transfer;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    final int PORT=8765;
    final List<SharedFile> files=Collections.synchronizedList(new ArrayList<>());
    ExecutorService pool=Executors.newCachedThreadPool();
    ServerSocket server;
    TextView status;
    String address="";
    static class SharedFile {
        String name; Uri uri; File local; String mime;
        SharedFile(String n, Uri u, File f, String m){name=n;uri=u;local=f;mime=m;}
    }
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        LinearLayout base=new LinearLayout(this);
        base.setOrientation(1); base.setPadding(30,55,30,20); base.setBackgroundColor(0xff08080b);
        TextView logo=label("◖  AirFlow",34,0xffF9373F,true); base.addView(logo);
        TextView desc=label("Deel bestanden op hetzelfde wifi-netwerk",17,Color.WHITE,false);base.addView(desc);
        status=label("Server starten...",16,0xffcccccc,false);base.addView(status);
        TextView guide=label("Open het adres hierboven in Safari, Chrome of op je computer. Je kunt bestanden downloaden of naar deze telefoon sturen.",15,0xffaaaaaa,false);base.addView(guide);
        Button choose=new Button(this);choose.setText("Kies bestanden");choose.setTextColor(Color.WHITE);choose.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xffF9373F));base.addView(choose);
        choose.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,1);});
        Button clear=new Button(this);clear.setText("Verwijder gedeelde bestanden");base.addView(clear);
        clear.setOnClickListener(v->{files.clear();updateStatus();});
        TextView warning=label("Prototype: gebruik alleen vertrouwde wifi. Houd AirFlow open tijdens overdracht.",13,0xffaaaaaa,false);base.addView(warning);
        ScrollView scroll=new ScrollView(this);scroll.addView(base);setContentView(scroll);
        readIntent(getIntent()); startServer();
    }
    TextView label(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setPadding(0,0,0,24);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);readIntent(i);}
    void readIntent(Intent i){
        if(i==null)return;
        if(Intent.ACTION_SEND.equals(i.getAction())){
            Uri u=i.getParcelableExtra(Intent.EXTRA_STREAM);
            if(u!=null)addUri(u);
        }else if(Intent.ACTION_SEND_MULTIPLE.equals(i.getAction())){
            ArrayList<Uri> us=i.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if(us!=null)for(Uri u:us)addUri(u);
        }
        updateStatus();
    }
    void addUri(Uri u){
        String n="bestand-"+(files.size()+1);
        try(android.database.Cursor c=getContentResolver().query(u,null,null,null,null)){
            if(c!=null&&c.moveToFirst()){int idx=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(idx>=0)n=c.getString(idx);}
        }catch(Exception ignored){}
        files.add(new SharedFile(n,u,null,getContentResolver().getType(u)));
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req==1&&result==RESULT_OK&&data!=null){
            if(data.getClipData()!=null)for(int j=0;j<data.getClipData().getItemCount();j++)addUri(data.getClipData().getItemAt(j).getUri());
            else if(data.getData()!=null)addUri(data.getData());
            updateStatus();
        }
    }
    String ip(){
        try{
            WifiManager wm=(WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            int v=wm.getConnectionInfo().getIpAddress();
            if(v!=0)return String.format(java.util.Locale.US,"%d.%d.%d.%d",v&255,(v>>8)&255,(v>>16)&255,(v>>24)&255);
        }catch(Exception ignored){}
        return null;
    }
    void updateStatus(){
        runOnUiThread(()->{
            if(status!=null)status.setText((address.isEmpty()?"Verbind met wifi om te delen":("Open op je andere apparaat:\n"+address))+"\n"+files.size()+" bestand(en) klaar om te delen");
        });
    }
    void startServer(){
        pool.execute(()->{
            try{
                server=new ServerSocket(PORT);
                String host=ip();address=host==null?"":"http://"+host+":"+PORT;
                updateStatus();
                while(!server.isClosed()){Socket s=server.accept();s.setSoTimeout(30000);pool.execute(()->handle(s));}
            }catch(Exception e){runOnUiThread(()->status.setText("Serverfout: "+e.getMessage()));}
        });
    }
    String escape(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");}
    String page(){
        StringBuilder b=new StringBuilder();
        b.append("<!doctype html><html lang='nl'><meta name='viewport' content='width=device-width,initial-scale=1'><meta charset='utf-8'><title>AirFlow</title>");
        b.append("<style>body{font:16px system-ui;background:#08080b;color:white;margin:0;padding:28px;max-width:700px}h1{color:#F9373F;font-size:38px}a{color:#ff5860}li{padding:12px;background:#222;margin:8px 0;border-radius:12px;list-style:none}ul{padding:0}button{background:#F9373F;color:white;border:0;padding:15px;border-radius:12px;font-size:16px}input{margin:15px 0}</style>");
        b.append("<h1>◖ AirFlow</h1><p>Bestanden delen via wifi</p><h2>Beschikbaar om te downloaden</h2><ul>");
        synchronized(files){for(int i=0;i<files.size();i++)b.append("<li><a href='/file/").append(i).append("'>").append(escape(files.get(i).name)).append("</a></li>");}
        b.append("</ul><h2>Verstuur naar deze Android</h2><input type='file' id='f' multiple><br><button onclick='send()'>Versturen</button><p id='status'></p>");
        b.append("<script>async function send(){const f=document.getElementById('f').files;let s=document.getElementById('status');for(let x of f){s.textContent='Versturen: '+x.name;try{let r=await fetch('/upload?name='+encodeURIComponent(x.name),{method:'POST',headers:{'Content-Type':'application/octet-stream'},body:x});if(!r.ok)throw Error(r.status)}catch(e){s.textContent='Fout: '+e;return}}s.textContent='Verzonden!';location.reload()}</script></html>");
        return b.toString();
    }
    void response(OutputStream out,int code,String type,byte[] body){
        try{
            String head="HTTP/1.1 "+code+" "+(code==200?"OK":"Error")+"\r\nContent-Type: "+type+"\r\nContent-Length: "+body.length+"\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n";
            out.write(head.getBytes("UTF-8"));out.write(body);out.flush();
        }catch(Exception ignored){}
    }
    void handle(Socket socket){
        try(Socket s=socket){
            InputStream in=new BufferedInputStream(s.getInputStream());OutputStream out=new BufferedOutputStream(s.getOutputStream());
            ByteArrayOutputStream header=new ByteArrayOutputStream();
            int v;byte[] end={'\r','\n','\r','\n'};int match=0;
            while((v=in.read())!=-1&&header.size()<16384){
                header.write(v);if(v==end[match])match++;else match=(v==end[0]?1:0);if(match==4)break;
            }
            String h=header.toString("ISO-8859-1");String[] lines=h.split("\r\n");if(lines.length==0)return;
            String[] req=lines[0].split(" ");if(req.length<2)return;
            String method=req[0],path=req[1];long length=0;
            for(String line:lines)if(line.toLowerCase(java.util.Locale.ROOT).startsWith("content-length:"))length=Long.parseLong(line.substring(line.indexOf(':')+1).trim());
            if(method.equals("GET")&&path.equals("/"))response(out,200,"text/html; charset=utf-8",page().getBytes("UTF-8"));
            else if(method.equals("GET")&&path.startsWith("/file/")){
                int index=Integer.parseInt(path.substring(6).split("\\?")[0]);
                SharedFile f; synchronized(files){f=files.get(index);}
                InputStream src=f.local!=null?new FileInputStream(f.local):getContentResolver().openInputStream(f.uri);
                if(src==null)throw new IOException("File unavailable");
                try(InputStream content=src){
                    byte[] bytes=new byte[16384];ByteArrayOutputStream data=new ByteArrayOutputStream();int n;
                    while((n=content.read(bytes))!=-1)data.write(bytes,0,n);
                    response(out,200,"application/octet-stream",data.toByteArray());
                }
            }else if(method.equals("POST")&&path.startsWith("/upload?name=")){
                if(length<0||length>500000000L){response(out,413,"text/plain","File too large".getBytes());return;}
                String name=URLDecoder.decode(path.substring(path.indexOf("name=")+5).split("&")[0],"UTF-8");
                name=name.replaceAll("[\\\\/:*?\"<>|]","_");if(name.isEmpty())name="upload";
                File dir=new File(getFilesDir(),"received");dir.mkdirs();
                File dest=File.createTempFile("airflow-","-"+name,dir);
                try(OutputStream f=new FileOutputStream(dest)){byte[] buf=new byte[32768];long remain=length;while(remain>0){int n=in.read(buf,0,(int)Math.min(buf.length,remain));if(n<0)throw new EOFException();f.write(buf,0,n);remain-=n;}}
                files.add(new SharedFile(name,null,dest,"application/octet-stream"));updateStatus();
                response(out,200,"text/plain","OK".getBytes("UTF-8"));
            }else response(out,404,"text/plain","Not found".getBytes("UTF-8"));
        }catch(Exception ignored){}
    }
    @Override protected void onDestroy(){super.onDestroy();try{if(server!=null)server.close();}catch(Exception ignored){}pool.shutdownNow();}
}
