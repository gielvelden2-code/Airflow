plugins { id("com.android.application") }
android {
    namespace = "com.airflow.transfer"
    compileSdk = 35
    defaultConfig { applicationId = "com.airflow.transfer"; minSdk = 26; targetSdk = 28; versionCode = 1; versionName = "0.1" }
}
